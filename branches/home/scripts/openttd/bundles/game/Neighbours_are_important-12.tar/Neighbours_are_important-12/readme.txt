Hello!

Thanks for interest in the Game Script "Neighbours are important". 

This game script adds goals for town growth with an extra twist. If you just pick 
a single town and try to grow it you will find that the goals will get very hard 
after a while. This is because the goals of a single town doesn't just depend on 
the size of that town, but also the size difference compared to its neighbours. 
The smaller neighbours a town have, the harder it become to grow that town. In 
some situations you will probably want to grow the neighbours first to lower the
requirements for your main town.

---- Congestion? ------------------------------------------------------------------
- Yes, if your town get too congested with road vehicles, it will stop growing 
or have a reduced growth rate. Both the congestion limit and the effect of 
congestion can be configured in the settings of this game script.

---- Stockpiles -------------------------------------------------------------------
If cargo delivery exceeds the requirement, the overflow will be stored by the town
for future use. Each stockpile is limited to at maximum 10 times the monthly
requirement. Though all stockpiles accept a minimum of 50 items regardless of the
current monthly requirement.

Note that stockpiles are managed by the Game Script and will not update at the same
time as when the cargo delivery information in the town window. The script uses a
different hook into cargo deliveries than the value that is displayed in the window
as to not loose cargo. The reason why it is not all synchronized is that for
performance reasons the GS need to distribute management of towns over the whole
month.

The stockpile feature in was kindly contributed as a patch by aantono

---- Manual town growth toggle ----------------------------------------------------
In the Game Script settings there is an option to enable manual town growth toggle.
If this is enabled, you can disable town growth for towns individually. In the script
setting you set a default value for all towns (growth ON or OFF), then put a "ON" or
"OFF" sign on the town tile for the towns that you want to reverse. The town tile is
the tile right under the town name. For most towns this is a road tile.

Note, that in the event of conflicting signs, one sign just win. (higher company IDs
have higher priority). For multiplayer games this feature should probably be turned
off unless there is a high level of trust among the players.

Also note that this feature is aimed towards players of Neighbours are important
that want to turn off town growth for specific towns. Currently there is no way to
only use this feature, but not the core features of this game script.

---- Master switch ----------------------------------------------------------------
There is a setting called "master switch" which allows to disable the script. When
you toggle this setting in a running game, the script will react and make changes
to the game. When you disable the script, it will remove all cargo goals and
set town growth to zero and then pass back the town growth control to OpenTTD.
Give it some time, and OpenTTD will resume towns back to normal town growth.

It is also possible to re-enable the script if figured out that plain town growth
is not that fun after all and want to get back the challenges of this script.

---- Found a bug? -----------------------------------------------------------------
- Please report it to the forum thread of this game script. Just click on view 
website in OpenTTD to get to the thread. If that doesn't work you can type in 
the address manually: http://www.tt-forums.net/viewtopic.php?f=65&t=57963

---- Suggestions/praise or just comments? -----------------------------------------
- Please post them to the forum thread (see Found a bug)
- Also, if you find that you had to fine-tune the scale factors in the settings, 
  please report back what values you used so that I get to know if the defaults 
  should be adjusted.

---- Translations -----------------------------------------------------------------
Translations of the script are welcome. Post them to the forums in UTF-8
encoding. 

Currently these languages exist:
- English
- German (SonicTTD)
- French (krinn)
- Russian (ziond)
- Swedish (Zuu)

If you don't get translations to work, you might be affected by this bug: 
http://bugs.openttd.org/task/5509


Have fun!
/ Zuu
