Hallo!

Herzlichen Dank f�r Dein Interesse an dem Game Skript "Neighbours are important".

Dieses Game Skript erstellt Zielstellungen f�r das St�dtewachstum auf eine etwas
andere Weise. Solltest Du Dir eine einzelne Stadt aussuchen, die Du wachsen
lassen m�chtest, wirst Du feststellen, dass die Ziele nach einer Weile sehr 
schwer zu erreichen sein werden. Die Ziele einer einzelnen Stadt h�ngen n�mlich
nicht nur von der Gr��e dieser Stadt, sondern auch von dem Gr��enunterschied
zu den Nachbarst�dten, ab. Je kleiner die Nachbarst�dte sind, desto schwieriger
wird es, diese einzelne Stadt wachsen zu lassen. In manchen Situationen wirst Du
also vermutlich erst die Nachbarst�dte wachsen lassen wollen, um die Bed�rfnisse
der Hauptstadt zu senken.

---- Verstopfung? -----------------------------------------------------------------
Ja, wenn Deine Stadt eine zu hohe Verkehrsbelastung hat, wird sie aufh�ren zu
wachsen oder eine verringerte Wachstumsrate aufweisen. Das Verstopfungslimit, sowie
der Verstopfungseffekt k�nnen in den Eintellungen dieses Skripts ver�ndert werden.

---- Lagerbestand -----------------------------------------------------------------
Falls die Warenlieferungen die Vorgaben �bertreffen, werden die �bersch�ssigen
Waren, f�r eine zuk�nftige Nutzung, in der Stadt gelagert.
Die Lagerkapazit�t jeder Ware ist auf das 10-fache der monatlichen Vorgaben
begrenzt, jedoch nie kleiner als 50 Einheiten pro Frachtart.

Bemerke:
Diese Lagebest�nde werden von dem Game Skript verwaltet, und werden nicht zur
gleichen Zeit wie die Wareninformationen vom "Stadtfenster" aktualisiert. Das
Skript nutzt eine andere Methode als die des "Stadtfensters" um keine Waren zu
verlieren. Aus Performance-Gr�nden k�nnen nicht alle St�dte synchronisiert werden.
Das Game Skript muss das St�dte-Management �ber den gesamten Monat verteilen.

Das Lager-Feature wurde als Patch freundlicherweise von aantono beigesteuert.

---- Manueller Stadtwachstumsschalter ---------------------------------------------
In den Einstellungen des Game Skripts gibt es eine Einstellung f�r den manuellen
Stadtwachstumsschalter. Falls dieser eingeschaltet ist, kannst Du das Stadtwachstum
einzelner St�dte abschalten. In den Einstellungen setzt Du einen Standardwert f�r
alle St�dte (An oder Aus). Dann platzierst Du ein Schild mit "On" f�r "An" oder
"Off" f�r "Aus", auf dem Feld unter dem Stadtnamen der Stadt deren Wachstum Du
starten oder stoppen m�chtest. Meistens ist auf diesem Feld eine Stra�e.

Bemerke:
Falls sich Schilder widersprechen, gewinnt eines der Schilder. (H�here Firmen-IDs
haben h�here Priorit�t). F�r Multiplayer-Spiele sollte dieses Feature ausgeschaltet
werden, es sei denn, Du setzt ein hohes Vertrauen in Deine Mitspieler. 

Bemerke auch:
Dieses Feature richtet sich an Spieler von Neighbours are important die das
Wachstum bestimmter St�dte verhindern wollen. Im Moment gibt es keinen Weg dieses
Feature, allein ohne weitere Kernfeatures dieses Skripts, zu benutzen. 

---- Hauptschalter ----------------------------------------------------------------
Es gibt in den Einstellung einen "Hauptschalter" ("master switch") der es Dir
erlaubt das Skript zu deaktivieren. Legst Du diesen w�hrend eines laufenden Spiels
um, wird das Skript reagieren und �nderungen am Spiel vornehmen. Falls Du das 
Skript deaktivierst, werden alle Zielstellungen gel�scht. Das Stadtwachstum wird
erst auf "0" gesetzt und dann OpenTTD �bergeben. Nach einer Weile wird OpenTTD zum
normalen St�dtewachstum zur�ckkehren.

Es ist auch m�glich das Skript zu reaktivieren falls man feststellt, dass das
normale Stadtwachstum nicht so spassbringend ist wie mit den durch das Skript
vorgebenen Herausforderungen.

---- Bugs gefunden? ---------------------------------------------------------------
Bitte berichte von im Skript gefundenen Bugs im Forum-Thread. Um diesen Aufzurufen
kannst Du in OpenTTD einfach auf "Webseite anzeigen" klicken. Sollte das nicht
funktionieren kannst Du die folgende Adresse manuell eingeben:
http://www.tt-forums.net/viewtopic.php?f=65&t=57963

---- Vorschl�ge/Lobhuldigungen oder einfach nur Kommentare? -----------------------
- Bitte reiche diese im Forum-Thread ein (siehe "Bugs gefunden?")
- Au�erdem, falls Du Skalierungsfaktoren in den Einstellungen vor�ndern musstest,
  berichte �ber diese �nderungen im Forum-Thread, so dass der Autor des Skripts
  die Standards eventuell anpassen kann
